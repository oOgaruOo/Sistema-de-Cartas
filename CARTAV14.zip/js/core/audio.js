/* ============================================================
   audio.js · v9 — instrumentos + fanfarrias + CORTE LIMPIO
   - NUEVO: puerta maestra (GainNode) para la música de fondo.
     Al cambiar de canción, la puerta se cierra al instante: la
     canción anterior se corta (no más dos tonos solapados en la
     portada) y la nueva arranca limpia.
   - Piano, guitarra/arpa Karplus-Strong, celesta, cuerdas: uno
     por tema. Fanfarrias finales más altas (celebrar).
   - AudioFX.pop(): corcho del regalo.
   ============================================================ */
(function (App) {
  'use strict';

  var ctx = null;
  var activado = true;
  var MASTER = 1.0;

  /* ---- puerta maestra de la música de fondo ----
     Todo lo que toca el MOTOR (no los efectos) pasa por aquí.
     cerrarPuerta() corta la canción en curso de inmediato. */
  var puerta = null;
  function asegurarPuerta() {
    if (!ctx) return null;
    if (!puerta) {
      puerta = ctx.createGain();
      puerta.gain.value = 1;
      puerta.connect(ctx.destination);
    }
    return puerta;
  }
  function cerrarPuerta() {
    if (!ctx || !puerta) return;
    var t = ctx.currentTime;
    try {
      puerta.gain.cancelScheduledValues(t);
      puerta.gain.setValueAtTime(puerta.gain.value, t);
      puerta.gain.linearRampToValueAtTime(.0001, t + .03);   /* corte de 30 ms */
    } catch (e) {}
  }
  function abrirPuerta() {
    if (!ctx || !puerta) return;
    var t = ctx.currentTime;
    try {
      puerta.gain.cancelScheduledValues(t);
      puerta.gain.setValueAtTime(puerta.gain.value, t);
      puerta.gain.linearRampToValueAtTime(1, t + .05);
    } catch (e) {}
  }

  var MUSICA_BASE = {
    compas: 3400, paso: .5, vol: .085, nota: 392, acorde: 196, instrumento: 'piano',
    progresion: [
      { bajo: 110.00, notas: [220.00, 261.63, 329.63, 440.00, 329.63, 261.63] },
      { bajo:  87.31, notas: [174.61, 220.00, 261.63, 349.23, 261.63, 220.00] },
      { bajo: 130.81, notas: [261.63, 329.63, 392.00, 523.25, 392.00, 329.63] },
      { bajo:  98.00, notas: [196.00, 246.94, 293.66, 392.00, 293.66, 246.94] },
      { bajo:  82.41, notas: [164.81, 196.00, 246.94, 329.63, 246.94, 196.00] },
      { bajo: 110.00, notas: [220.00, 261.63, 329.63, 440.00, 329.63, 261.63] },
      { bajo:  87.31, notas: [174.61, 220.00, 261.63, 349.23, 261.63, 220.00] },
      { bajo:  82.41, notas: [164.81, 207.65, 246.94, 329.63, 246.94, 207.65] }
    ]
  };

  var INSTR_POR_CFG = {
    '392':    'piano',
    '349.23': 'guitarra',
    '523.25': 'campanas',
    '493.88': 'arpa',
    '440':    'cuerdas',
    '659.25': 'campanas'
  };
  function instrumentoDe(cfg) {
    if (cfg && cfg.instrumento) return cfg.instrumento;
    return INSTR_POR_CFG[cfg ? String(cfg.nota) : ''] || 'caja';
  }

  function asegurar() {
    if (!activado) return null;
    try {
      if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === 'suspended') ctx.resume();
      asegurarPuerta();
      return ctx;
    } catch (e) { return null; }
  }

  /* ============================================================
     INSTRUMENTOS (los del MOTOR conectan a la puerta; los de
     fanfarrias y efectos van directos al destino)
     ============================================================ */

  var KS_CACHE = {};
  function ksBuffer(freq, damp) {
    var key = (Math.round(freq * 10) / 10) + '|' + damp;
    if (KS_CACHE[key]) return KS_CACHE[key];
    var sr = ctx.sampleRate;
    var N = Math.max(2, Math.round(sr / freq));
    var len = Math.floor(sr * 2.4);
    var buf = ctx.createBuffer(1, len, sr);
    var data = buf.getChannelData(0);
    var ring = new Float32Array(N);
    for (var i = 0; i < N; i++) ring[i] = Math.random() * 2 - 1;
    var idx = 0;
    for (i = 0; i < len; i++) {
      var cur = ring[idx];
      var nxt = ring[(idx + 1) % N];
      ring[idx] = damp * .5 * (cur + nxt);
      data[i] = cur;
      idx++; if (idx >= N) idx = 0;
    }
    KS_CACHE[key] = buf;
    return buf;
  }

  /* destino: 'motor' (puerta) o 'directo' (destination) */
  function salida(modo) {
    if (modo === 'motor') { asegurarPuerta(); return puerta; }
    return ctx.destination;
  }

  function pluckNota(freq, t, vol, damp, sustain, destino) {
    var src = ctx.createBufferSource();
    src.buffer = ksBuffer(freq, damp);
    var f = ctx.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = 3400;
    var g = ctx.createGain();
    var d = sustain || 2.1;
    g.gain.setValueAtTime(vol * MASTER, t);
    g.gain.exponentialRampToValueAtTime(.0001, t + d);
    src.connect(f); f.connect(g); g.connect(salida(destino));
    src.start(t);
  }

  function campana(freq, t, vol, sustain, destino) {
    var s = sustain || 1.5;
    var par = [[1, 1, 1], [2.71, .22, .55], [5.15, .09, .3]];
    for (var i = 0; i < par.length; i++) {
      var o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sine';
      o.frequency.value = freq * par[i][0];
      var d = Math.max(.18, s * par[i][2]);
      g.gain.setValueAtTime(.0001, t);
      g.gain.exponentialRampToValueAtTime(vol * MASTER * par[i][1], t + .006);
      g.gain.exponentialRampToValueAtTime(.0001, t + d);
      o.connect(g); g.connect(salida(destino));
      o.start(t); o.stop(t + d + .05);
    }
  }

  function martillo(t, vol, freq, destino) {
    var len = Math.floor(ctx.sampleRate * .03);
    var nb = ctx.createBuffer(1, len, ctx.sampleRate);
    var nd = nb.getChannelData(0);
    for (var i = 0; i < len; i++) nd[i] = (Math.random() * 2 - 1) * (1 - i / len);
    var src = ctx.createBufferSource(); src.buffer = nb;
    var f = ctx.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = Math.min(2400, freq * 4);
    var g = ctx.createGain();
    g.gain.setValueAtTime(vol * MASTER * .18, t);
    g.gain.exponentialRampToValueAtTime(.0001, t + .035);
    src.connect(f); f.connect(g); g.connect(salida(destino));
    src.start(t);
  }

  function pianoNota(freq, t, vol, sustain, destino) {
    var s = sustain || 2.2;
    var par = [[1, 1, 1], [2, .34, .6], [3, .16, .38], [4.02, .07, .24]];
    for (var i = 0; i < par.length; i++) {
      var o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sine';
      o.frequency.value = freq * par[i][0];
      var d = Math.max(.15, s * par[i][2]);
      g.gain.setValueAtTime(.0001, t);
      g.gain.exponentialRampToValueAtTime(vol * MASTER * par[i][1], t + .008);
      g.gain.exponentialRampToValueAtTime(.0001, t + d);
      o.connect(g); g.connect(salida(destino));
      o.start(t); o.stop(t + d + .05);
    }
    var o2 = ctx.createOscillator(), g2 = ctx.createGain();
    o2.type = 'sine'; o2.frequency.value = freq * 1.0016;
    g2.gain.setValueAtTime(.0001, t);
    g2.gain.exponentialRampToValueAtTime(vol * MASTER * .4, t + .008);
    g2.gain.exponentialRampToValueAtTime(.0001, t + s * .85);
    o2.connect(g2); g2.connect(salida(destino));
    o2.start(t); o2.stop(t + s * .85 + .05);
    martillo(t, vol, freq, destino);
  }

  function cuerdaNota(freq, t, vol, dur, destino) {
    var d = dur || 2;
    var f = ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.setValueAtTime(650, t);
    f.frequency.linearRampToValueAtTime(1600, t + Math.min(.5, d * .4));
    var g = ctx.createGain();
    g.gain.setValueAtTime(.0001, t);
    g.gain.linearRampToValueAtTime(vol * MASTER, t + .14);
    g.gain.setValueAtTime(vol * MASTER, Math.max(t + .14, t + d - .6));
    g.gain.exponentialRampToValueAtTime(.0001, t + d);
    f.connect(g); g.connect(salida(destino));
    var cents = [-7, 0, 7];
    for (var i = 0; i < 3; i++) {
      var o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.value = freq * Math.pow(2, cents[i] / 1200);
      var og = ctx.createGain(); og.gain.value = .33;
      o.connect(og); og.connect(f);
      o.start(t); o.stop(t + d + .05);
    }
  }

  function notaCaja(freq, t, vol) {
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = 'sine'; o.frequency.value = freq;
    g.gain.setValueAtTime(.0001, t);
    g.gain.exponentialRampToValueAtTime(vol * MASTER, t + .02);
    g.gain.exponentialRampToValueAtTime(.0001, t + 1.9);
    o.connect(g); g.connect(salida('motor'));
    o.start(t); o.stop(t + 2);
    var o2 = ctx.createOscillator(), g2 = ctx.createGain();
    o2.type = 'sine'; o2.frequency.value = freq * 2;
    g2.gain.setValueAtTime(.0001, t);
    g2.gain.exponentialRampToValueAtTime(vol * MASTER * .28, t + .015);
    g2.gain.exponentialRampToValueAtTime(.0001, t + .9);
    o2.connect(g2); g2.connect(salida('motor'));
    o2.start(t); o2.stop(t + 1);
  }

  function bajoSuave(freq, t, vol) {
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = 'sine'; o.frequency.value = freq;
    g.gain.setValueAtTime(.0001, t);
    g.gain.exponentialRampToValueAtTime(vol * MASTER, t + .5);
    g.gain.setValueAtTime(vol * MASTER, t + 2.4);
    g.gain.exponentialRampToValueAtTime(.0001, t + 3.4);
    o.connect(g); g.connect(salida('motor'));
    o.start(t); o.stop(t + 3.5);
  }

  function notaInstrumento(instr, freq, t, vol, sustain, destino) {
    if (instr === 'guitarra') pluckNota(freq, t, vol * 1.35, .996, sustain, destino);
    else if (instr === 'arpa') pluckNota(freq, t, vol * 1.35, .993, sustain, destino);
    else if (instr === 'campanas') campana(freq, t, vol * 1.15, sustain, destino);
    else if (instr === 'piano') pianoNota(freq, t, vol * 1.15, sustain, destino);
    else if (instr === 'cuerdas') cuerdaNota(freq, t, vol * 1.15, sustain || 1.8, destino);
    else notaCaja(freq, t, vol);
  }

  function bajoTema(instr, freq, t, vol, destino) {
    if (instr === 'guitarra' || instr === 'arpa') pluckNota(freq, t, vol * 1.15, .996, 2.6, destino);
    else if (instr === 'piano') pianoNota(freq, t, vol * 1.1, 2.6, destino);
    else bajoSuave(freq, t, vol);
  }

  /* ---------- efectos puntuales (directos) ---------- */
  function tono(freq, t0, dur, vol, tipo) {
    var c = asegurar(); if (!c) return;
    var t = c.currentTime + t0;
    var o = c.createOscillator(), g = c.createGain();
    o.type = tipo || 'triangle';
    o.frequency.value = freq;
    g.gain.setValueAtTime(.0001, t);
    g.gain.exponentialRampToValueAtTime(vol * MASTER, t + .012);
    g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.connect(g); g.connect(c.destination);
    o.start(t); o.stop(t + dur + .05);
  }

  function golpe(freq, t0, dur, vol) {
    var c = asegurar(); if (!c) return;
    var t = c.currentTime + t0;
    var o = c.createOscillator(), g = c.createGain();
    o.type = 'triangle';
    o.frequency.setValueAtTime(freq, t);
    o.frequency.exponentialRampToValueAtTime(freq * .6, t + dur);
    g.gain.setValueAtTime(.0001, t);
    g.gain.exponentialRampToValueAtTime(vol * MASTER, t + .01);
    g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.connect(g); g.connect(c.destination);
    o.start(t); o.stop(t + dur + .05);
  }

  function ruido(t0, dur, vol, freq, q) {
    var c = asegurar(); if (!c) return;
    var len = Math.max(1, (dur * c.sampleRate) | 0);
    var buf = c.createBuffer(1, len, c.sampleRate);
    var d = buf.getChannelData(0);
    for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    var src = c.createBufferSource(); src.buffer = buf;
    var f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q;
    var g = c.createGain();
    var t = c.currentTime + t0;
    g.gain.setValueAtTime(vol * MASTER, t);
    g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(c.destination);
    src.start(t); src.stop(t + dur + .02);
  }

  /* ============================================================
     MOTOR (etiquetado + PUERTA: corte real al cambiar)
     ============================================================ */
  var musica = {
    iniciada: false, etiqueta: 0, temporizador: null,
    indice: 0, reintentos: 0, cfg: MUSICA_BASE,
    fanfarria: false, fanfarriaHasta: 0
  };

  function fanfarriaViva() {
    return musica.fanfarria && Date.now() < musica.fanfarriaHasta;
  }

  function compas(miEtiqueta) {
    if (miEtiqueta !== musica.etiqueta) return false;
    if (!activado || !ctx || ctx.state !== 'running') return false;
    var m = musica.cfg;
    var instr = instrumentoDe(m);
    var c = m.progresion[musica.indice % m.progresion.length];
    musica.indice++;
    var t = ctx.currentTime + .06;
    bajoTema(instr, c.bajo, t, (m.vol || .085) * .9, 'motor');
    var paso = m.paso || .5, vol = m.vol || .085;
    for (var i = 0; i < c.notas.length; i++) {
      notaInstrumento(instr, c.notas[i], t + .18 + i * paso, vol + Math.random() * .02, undefined, 'motor');
    }
    return true;
  }

  function programarSiguiente() {
    if (musica.temporizador) { clearTimeout(musica.temporizador); musica.temporizador = null; }
    var m = musica.cfg;
    var espera = m.compas || 3400;
    var miEtiqueta = musica.etiqueta;
    musica.temporizador = setTimeout(function () {
      musica.temporizador = null;
      if (miEtiqueta !== musica.etiqueta) return;
      if (compas(miEtiqueta)) programarSiguiente();
      else if (musica.reintentos < 20) {
        musica.reintentos++;
        setTimeout(function () {
          if (miEtiqueta === musica.etiqueta && !fanfarriaViva()) { asegurar(); programarSiguiente(); }
        }, 200);
      }
    }, espera);
  }

  function arrancarCancion() {
    if (fanfarriaViva()) return;
    musica.fanfarria = false;
    if (!activado || !ctx) return;
    musica.reintentos = 0;
    abrirPuerta();          /* la puerta abre antes de cada arranque */
    if (compas(musica.etiqueta)) {
      programarSiguiente();
    } else if (musica.reintentos < 20) {
      musica.reintentos++;
      var miEtiqueta = musica.etiqueta;
      setTimeout(function () {
        if (miEtiqueta === musica.etiqueta && !fanfarriaViva()) { asegurar(); arrancarCancion(); }
      }, 200);
    }
  }

  function pararMusica() {
    musica.etiqueta++;
    if (musica.temporizador) { clearTimeout(musica.temporizador); musica.temporizador = null; }
    cerrarPuerta();         /* EL CORTE: lo que sonaba se apaga YA */
  }

  document.addEventListener('visibilitychange', function () {
    if (document.hidden) pararMusica();
    else if (activado && musica.iniciada && !fanfarriaViva()) arrancarCancion();
  });

  function desbloquear() {
    var c = asegurar();
    if (!c) return;
    try {
      var o = c.createOscillator(), g = c.createGain();
      g.gain.value = .0001;
      o.connect(g); g.connect(c.destination);
      o.start(0); o.stop(c.currentTime + .05);
    } catch (e) {}
    if (!musica.iniciada) {
      musica.iniciada = true;
      if (activado) setTimeout(arrancarCancion, 500);
    }
  }
  if (document.addEventListener) {
    document.addEventListener('pointerdown', desbloquear, { once: true });
    document.addEventListener('keydown', desbloquear, { once: true });
  }

  /* ============================================================
     FANFARRIAS (directas: suenan aunque la puerta esté cerrada)
     ============================================================ */
  function N(instr, freq, ms, vol, sustain) {
    notaInstrumento(instr, freq, ctx.currentTime + ms / 1000, vol, sustain, 'directo');
  }
  function BASS(instr, freq, ms, vol) {
    bajoTema(instr, freq, ctx.currentTime + ms / 1000, vol, 'directo');
  }
  function STR(freq, ms, vol, dur) {
    cuerdaNota(freq, ctx.currentTime + ms / 1000, vol, dur, 'directo');
  }

  var FANFARRIAS = {
    disculpa: function () {
      BASS('piano', 110, 0, .22);
      N('piano', 440, 0, .22);
      N('piano', 523.25, 210, .22);
      N('piano', 659.25, 420, .22);
      N('piano', 880, 630, .26, 2.6);
      [220, 277.18, 329.63, 440].forEach(function (f, i) { STR(f, 880 + i * 45, .13, 3.2); });
      campana(1760, ctx.currentTime + 1.05, .08, undefined, 'directo');
      return 4600;
    },
    teextrano: function () {
      BASS('guitarra', 87.31, 0, .22);
      [349.23, 440, 523.25, 698.46, 880, 1046.5].forEach(function (f, i) {
        N('guitarra', f, i * 150, .24);
      });
      N('guitarra', 880, 960, .2);
      N('guitarra', 698.46, 1090, .19);
      N('guitarra', 880, 1260, .23, 2.4);
      [174.61, 220, 261.63, 349.23].forEach(function (f, i) {
        N('guitarra', f, 1460 + i * 45, .24, 2.4);
      });
      return 5200;
    },
    cumple: function () {
      BASS('campanas', 130.81, 0, .22);
      [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) {
        N('campanas', f, i * 140, .28);
      });
      N('campanas', 1318.5, 640, .2);
      N('campanas', 783.99, 800, .22);
      N('campanas', 1046.5, 950, .28, 2.6);
      [261.63, 329.63, 392, 523.25].forEach(function (f, i) {
        N('campanas', f, 1160 + i * 55, .22, 2.6);
      });
      return 4800;
    },
    madre: function () {
      BASS('arpa', 98, 0, .2);
      var gliss = [392, 440, 493.88, 523.25, 587.33, 659.25, 739.99, 783.99, 880, 987.77];
      gliss.forEach(function (f, i) {
        N('arpa', f, i * 90, .14 + i * .013);
      });
      [196, 246.94, 293.66, 392].forEach(function (f, i) {
        N('arpa', f, 1010 + i * 60, .26, 2.4);
      });
      STR(196, 1080, .1, 3);
      return 5200;
    },
    aniversario: function () {
      BASS('cuerdas', 110, 0, .22);
      [440, 554.37, 659.25, 880].forEach(function (f, i) {
        STR(f, 150 + i * 190, .19, 1.5);
      });
      [220, 277.18, 329.63, 440, 554.37].forEach(function (f, i) {
        STR(f, 1020 + i * 35, .22, 3.6);
      });
      campana(1318.51, ctx.currentTime + 1.15, .1, undefined, 'directo');
      return 5400;
    },
    flores: function () {
      BASS('campanas', 164.81, 0, .2);
      [659.25, 830.61, 987.77, 1318.5].forEach(function (f, i) {
        N('campanas', f, i * 130, .26);
      });
      N('arpa', 987.77, 620, .22);
      N('campanas', 1318.5, 760, .28, 2.6);
      [329.63, 415.3, 493.88, 659.25].forEach(function (f, i) {
        N('arpa', f, 960 + i * 55, .24, 2.4);
      });
      campana(1661.2, ctx.currentTime + 1.1, .08, undefined, 'directo');
      return 5000;
    }
  };

  /* ============================================================
     APIs PÚBLICAS
     ============================================================ */
  App.Musica = {
    arrancar: function () {
      var c = asegurar();
      if (!c) return;
      if (!musica.iniciada) musica.iniciada = true;
      if (activado && !musica.temporizador && !fanfarriaViva()) arrancarCancion();
    },

    /* Cambio con corte real: la puerta corta lo que sonaba y la
       nueva canción arranca limpia. Un solo tono, siempre. */
    cambiar: function (cfg) {
      if (!cfg || !cfg.progresion || !cfg.progresion.length) return;
      pararMusica();          /* corta la anterior YA (puerta) */
      musica.cfg = cfg;
      musica.indice = 0;
      if (musica.iniciada && activado && !fanfarriaViva()) arrancarCancion();
    },

    celebrar: function (temaId) {
      var c = asegurar();
      if (!c) return;
      pararMusica();          /* corta el fondo (puerta) */
      musica.fanfarria = true;
      var dur = 4500;
      try {
        var f = FANFARRIAS[temaId] || FANFARRIAS.disculpa;
        dur = f() || 4500;
      } catch (e) {}
      musica.fanfarriaHasta = Date.now() + dur;
      setTimeout(function () {
        if (Date.now() < musica.fanfarriaHasta) return;
        musica.fanfarria = false;
        if (activado && musica.iniciada) arrancarCancion();
      }, dur);
    },

    parar: pararMusica
  };

  App.AudioFX = {
    get activado() { return activado; },

    alternar: function () {
      activado = !activado;
      if (!activado) pararMusica();
      else if (musica.iniciada && !fanfarriaViva()) arrancarCancion();
    },

    _vigilar: function () {
      if (activado && musica.iniciada && !musica.temporizador && !fanfarriaViva()) arrancarCancion();
    },

    tecla:    function () { this._vigilar(); if (Math.random() < .8) tono(1250 + Math.random() * 950, 0, .05, .02, 'square'); },
    crujido:  function () { this._vigilar(); ruido(0, .16, .38, 850, 1.6); golpe(120, 0, .14, .16); },
    deslizar: function () { this._vigilar(); ruido(0, .42, .09, 650, .8); },
    sello:    function () { this._vigilar(); golpe(95, 0, .22, .34); ruido(0, .09, .2, 480, 1); golpe(48, .02, .18, .22); },

    pop:      function () {
      this._vigilar();
      var c = asegurar(); if (!c) return;
      var t = c.currentTime;
      var o = c.createOscillator(), g = c.createGain();
      o.type = 'triangle';
      o.frequency.setValueAtTime(420, t);
      o.frequency.exponentialRampToValueAtTime(110, t + .09);
      g.gain.setValueAtTime(.32 * MASTER, t);
      g.gain.exponentialRampToValueAtTime(.0001, t + .12);
      o.connect(g); g.connect(c.destination);
      o.start(t); o.stop(t + .14);
      ruido(0, .06, .24, 1500, .8);
      campana(1567.98, t + .05, .1, undefined, 'directo');
    },

    nota:     function (f) {
      this._vigilar();
      var instr = instrumentoDe(musica.cfg);
      var fr = f || (musica.cfg && musica.cfg.nota) || 392;
      notaInstrumento(instr, fr, ctx.currentTime, .16, undefined, 'directo');
      notaInstrumento(instr, fr * 1.5, ctx.currentTime + .04, .07, undefined, 'directo');
    },

    acorde:   function () {
      this._vigilar();
      var instr = instrumentoDe(musica.cfg);
      var raiz = (musica.cfg && musica.cfg.acorde) || 196;
      var t = ctx.currentTime;
      [1, 1.5, 2, 2.5, 3].forEach(function (m, i) {
        notaInstrumento(instr, raiz * m, t + i * .12, .14, 2.2, 'directo');
      });
      golpe(49, 0, .5, .12);
    },

    latido:   function () { this._vigilar(); golpe(60, 0, .26, .34); golpe(52, .30, .32, .28); }
  };
})(window.App = window.App || {});