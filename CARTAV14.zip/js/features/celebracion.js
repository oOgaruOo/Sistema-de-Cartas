/* ============================================================
   celebracion.js · v3 — el regalo animado del final, por tema
   - Aviones de papel reales, ambas direcciones, 7 unidades
   - Pastel grande con goteo, 7 velas y REGALOS clicables
     (¡POP! de corcho + picca picca + globos)
   - Ramos de 9 flores con gipsófila, chispas y mariposa
   - Anillos con diamante facetado · corazón con chispas
   ============================================================ */
(function (App) {
  'use strict';

  var REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;

  var cv = null, ctx = null, W = 0, H = 0;
  var escena = null, corazonEstatico = null, displayPrevio = '';
  var raf = null, corriendo = false, t0 = 0, tema = 'disculpa', lastNow = 0;

  var confeti = [], globosUsuario = [];
  var regaloIzq = null, regaloDer = null, hintRegalos = null;

  function init() {
    if (cv) return true;
    escena = document.getElementById('scene-forgiven');
    if (!escena) return false;

    var st = document.createElement('style');
    st.textContent =
      '#celebCanvas{ position:absolute; inset:0; width:100%; height:100%; pointer-events:none; }' +
      '#scene-forgiven .scene-inner{ position:relative; z-index:1; }' +
      '.celeb-regalo{ position:absolute; z-index:2; background:none; border:none; padding:0; cursor:pointer; transition:transform .2s ease; }' +
      '.celeb-regalo:hover{ transform:scale(1.07) rotate(-2deg); }' +
      '.celeb-regalo:focus-visible{ outline:2px dashed #c2483f; outline-offset:3px; }' +
      '.celeb-regalo svg{ width:100%; height:auto; display:block; filter:drop-shadow(0 6px 8px rgba(60,40,20,.28)); }' +
      '@keyframes celebSalto{ 0%{ transform:scale(1); } 30%{ transform:scale(.8) rotate(-5deg); } 60%{ transform:scale(1.16) rotate(4deg); } 100%{ transform:scale(1); } }' +
      '.celeb-regalo.rebote{ animation:celebSalto .45s ease; }' +
      '.celeb-hint{ position:absolute; z-index:2; transform:translateX(-50%); pointer-events:none; ' +
      '  font-family:\'Cormorant Garamond\',Georgia,serif; font-style:italic; font-size:14px; ' +
      '  color:#5e6e62; animation:celebHint 6s ease forwards; }' +
      '@keyframes celebHint{ 0%{ opacity:0; } 12%{ opacity:.95; } 70%{ opacity:.95; } 100%{ opacity:0; } }';
    document.head.appendChild(st);

    cv = document.createElement('canvas');
    cv.id = 'celebCanvas';
    cv.setAttribute('aria-hidden', 'true');
    escena.insertBefore(cv, escena.firstChild);
    ctx = cv.getContext('2d');

    crearRegalos();
    addEventListener('resize', redimensionar);
    redimensionar();
    return true;
  }

  function redimensionar() {
    if (!cv) return;
    var dpr = Math.min(devicePixelRatio || 1, 2);
    W = cv.clientWidth || escena.clientWidth;
    H = cv.clientHeight || escena.clientHeight;
    cv.width = Math.max(1, W * dpr);
    cv.height = Math.max(1, H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (REDUCED && tema === 'cumple' && !corriendo) dibujarFrame(t0 + 6000);
  }

  /* ---------- utilidades ---------- */
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function easeOut(x) { return 1 - Math.pow(1 - x, 3); }
  function easeBack(x) { var c = 1.70158; x -= 1; return x * x * ((c + 1) * x + c) + 1; }
  function qp(p0, p1, p2, t) {
    var u = 1 - t;
    return {
      x: u * u * p0.x + 2 * u * t * p1.x + t * t * p2.x,
      y: u * u * p0.y + 2 * u * t * p1.y + t * t * p2.y
    };
  }

  function estrella(x, y, s, color, alpha) {
    ctx.save();
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x, y - s);
    ctx.lineTo(x + s * .25, y - s * .25);
    ctx.lineTo(x + s, y);
    ctx.lineTo(x + s * .25, y + s * .25);
    ctx.lineTo(x, y + s);
    ctx.lineTo(x - s * .25, y + s * .25);
    ctx.lineTo(x - s, y);
    ctx.lineTo(x - s * .25, y - s * .25);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function chispitas(now, cx, cy, radio, n, color) {
    for (var i = 0; i < n; i++) {
      var a = i * 2.39996 + 1.1;
      var rr = radio * (0.45 + 0.5 * Math.abs(Math.sin(i * 7.31)));
      var x = cx + Math.cos(a) * rr + Math.sin(now * .0011 + i) * 7;
      var y = cy + Math.sin(a) * rr * .62 - ((now * .02 + i * 37) % 60) * .5;
      var alpha = .35 + .55 * Math.abs(Math.sin(now * .0032 + i * 2.1));
      estrella(x, y, 3 + (i % 3), color, alpha);
    }
  }

  function sombra(x, y, w) {
    ctx.beginPath();
    ctx.ellipse(x, y, w, w * .16, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(64,44,24,.13)';
    ctx.fill();
  }

  /* ---------- corazoncito relleno ---------- */
  var PUNTOS_CORAZON = null;
  function puntosCorazon() {
    if (PUNTOS_CORAZON) return PUNTOS_CORAZON;
    var segs = [
      [50, 76, 28, 60, 10, 46, 10, 28], [10, 28, 10, 14, 21, 7, 31, 7],
      [31, 7, 40, 7, 47, 13, 50, 20], [50, 20, 53, 13, 60, 7, 69, 7],
      [69, 7, 79, 7, 90, 14, 90, 28], [90, 28, 90, 46, 72, 60, 50, 76]
    ];
    function cub(p0, p1, p2, p3, t) {
      var u = 1 - t;
      return {
        x: u * u * u * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t * t * t * p3[0],
        y: u * u * u * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t * t * t * p3[1]
      };
    }
    var pts = [];
    for (var s = 0; s < segs.length; s++)
      for (var i = 0; i < 10; i++) {
        var g = segs[s];
        pts.push(cub([g[0], g[1]], [g[2], g[3]], [g[4], g[5]], [g[6], g[7]], i / 10));
      }
    pts.push({ x: 50, y: 76 });
    PUNTOS_CORAZON = pts;
    return pts;
  }

  function miniCorazon(x, y, s, color, alpha) {
    var pts = puntosCorazon();
    var k = s / 45;
    ctx.save();
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.translate(x - 50 * k, y - 45 * k);
    ctx.scale(k, k);
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (var j = 1; j < pts.length; j++) ctx.lineTo(pts[j].x, pts[j].y);
    ctx.closePath();
    ctx.fillStyle = color; ctx.fill();
    ctx.restore();
  }

  function latido(now) {
    var b = (now / 1000) % 1.3;
    if (b < .1) return Math.sin(Math.PI * b / .1) * .08;
    if (b > .18 && b < .3) return Math.sin(Math.PI * (b - .18) / .12) * .05;
    return 0;
  }

  /* ---------- corazón trazándose (pedir perdón) ---------- */
  function corazon(now) {
    var t = clamp((now - t0) / 1700, 0, 1);
    var cx = W / 2, cy = clamp(H * .32, 130, 300);
    var s = Math.min(W * .3, 175) * (0.85 + .15 * easeOut(t)) * (1 + latido(now) * t);

    for (var i = 0; i < 6; i++) {
      var ciclo = 240;
      var p = ((now * .022) + i * 40) % ciclo;
      var hx = cx + Math.sin(i * 2.1 + now * .001) * (W * .2);
      var hy = cy + s * .62 - p;
      miniCorazon(hx, hy, 9 + (i % 3) * 4, '#c76a63', (1 - p / ciclo) * .55);
    }
    chispitas(now, cx, cy, s * .95, 7, '#e0a89f');

    var pts = puntosCorazon();
    var n = Math.max(2, Math.round(pts.length * easeOut(t)));
    var esc = s / 90;

    if (t > .8) {
      var g = ctx.createRadialGradient(cx, cy, s * .2, cx, cy, s * 1.6);
      g.addColorStop(0, 'rgba(150,39,31,.17)');
      g.addColorStop(1, 'rgba(150,39,31,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(cx, cy, s * 1.6, 0, Math.PI * 2); ctx.fill();
    }

    ctx.save();
    ctx.translate(cx - 50 * esc, cy - 42 * esc);
    ctx.scale(esc, esc);

    if (t > .75) {
      ctx.globalAlpha = clamp((t - .75) / .25, 0, 1) * .16;
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (var k = 1; k < pts.length; k++) ctx.lineTo(pts[k].x, pts[k].y);
      ctx.closePath();
      ctx.fillStyle = '#96271f'; ctx.fill();
      ctx.globalAlpha = 1;
    }

    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (var j = 1; j < n; j++) ctx.lineTo(pts[j].x, pts[j].y);
    ctx.strokeStyle = '#96271f';
    ctx.lineWidth = 5.5;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.stroke();
    ctx.restore();
  }

  /* ---------- aviones de papel (te extraño) ---------- */
  var AVIONES = [
    { y: .15, v: 105, s: 1.00, dir:  1, f: 0    },
    { y: .30, v:  68, s: 1.35, dir: -1, f: 380  },
    { y: .44, v: 132, s:  .78, dir:  1, f: 640  },
    { y: .23, v:  54, s: 1.50, dir: -1, f: 900  },
    { y: .56, v:  88, s:  .95, dir:  1, f: 1250 },
    { y: .38, v: 150, s:  .68, dir:  1, f: 1550 },
    { y: .63, v:  60, s: 1.20, dir: -1, f: 1850 }
  ];

  function dibujarAvion(x, y, esc, dir, ang, alpha) {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(x, y);
    ctx.rotate(ang);
    ctx.scale(dir * esc, esc);

    ctx.beginPath();
    ctx.moveTo(62, -2);
    ctx.lineTo(-46, -42);
    ctx.lineTo(-14, -2);
    ctx.closePath();
    ctx.fillStyle = '#f8efdc'; ctx.fill();
    ctx.strokeStyle = '#a9552e'; ctx.lineWidth = 3; ctx.lineJoin = 'round'; ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(62, -2);
    ctx.lineTo(-14, -2);
    ctx.lineTo(-40, 30);
    ctx.closePath();
    ctx.fillStyle = '#e9d3a4'; ctx.fill(); ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(62, -2);
    ctx.lineTo(-32, 18);
    ctx.strokeStyle = '#c98f3d'; ctx.lineWidth = 2; ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(62, -2); ctx.lineTo(38, -9); ctx.lineTo(34, -2);
    ctx.closePath();
    ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.fill();

    ctx.restore();
  }

  function aviones(now) {
    var kEsc = clamp(Math.min(W, 760) / 700, .55, 1.1);
    for (var i = 0; i < AVIONES.length; i++) {
      var a = AVIONES[i];
      var ciclo = W + 340 * a.s;
      var x = ((now * .001 * a.v + a.f) % ciclo) - 170 * a.s;
      if (a.dir === -1) x = W - x;
      var y = H * a.y
            + Math.sin(now * .0011 + i * 1.9) * 11
            + Math.sin(now * .0004 + i) * 16;
      var esc = a.s * kEsc;
      var alpha = .5 + clamp(a.s - .6, 0, .9) * .5;
      var ang = a.dir * -.05 + Math.sin(now * .0013 + i * 2.3) * .1;

      var colaX = x - a.dir * 52 * esc;
      ctx.save();
      ctx.setLineDash([4, 10]);
      ctx.lineDashOffset = -(now * .06) * a.dir;
      ctx.strokeStyle = 'rgba(169,85,46,' + (alpha * .45).toFixed(2) + ')';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(colaX, y + 6 * esc);
      ctx.quadraticCurveTo(colaX - a.dir * 90 * esc, y + 15 * esc, colaX - a.dir * 170 * esc, y + 9 * esc);
      ctx.stroke();
      ctx.restore();

      dibujarAvion(x, y, esc, a.dir, ang, alpha);
    }
  }

  /* ---------- anillos con diamante (aniversario) ---------- */
  function anillos(now) {
    var t = clamp((now - t0) / 1500, 0, 1);
    var s = easeOut(t);
    var cx = W / 2, cy = clamp(H * .32, 140, 320);
    var r = Math.min(W * .2, 118) * s;
    if (r < 2) return;
    var k = r / 95;

    for (var i = 0; i < 8; i++) {
      var ciclo = 150;
      var p = ((now * .028) + i * 19) % ciclo;
      var sx = cx + Math.sin(i * 2.4) * r * 1.9;
      var sy = cy + r * .8 - p;
      estrella(sx, sy, 4 + (i % 3) * 2, '#e8c9a0', (1 - p / ciclo) * .85);
    }

    miniCorazon(cx - r * 1.4, cy + r * .5 - ((now * .03) % 130), 11, '#c9779a', .55);
    miniCorazon(cx + r * 1.5, cy + r * .6 - ((now * .024 + 60) % 130), 9, '#9c4a6c', .5);

    var dx = r * .52;
    ctx.lineWidth = Math.max(6, r * .13);
    ctx.strokeStyle = '#c9a24a';
    ctx.beginPath(); ctx.arc(cx - dx, cy, r, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx + dx, cy, r, 0, Math.PI * 2); ctx.stroke();

    var a0 = now * .0022;
    ctx.lineWidth = Math.max(3, r * .07);
    ctx.strokeStyle = '#f7e7bd';
    ctx.lineCap = 'round';
    ctx.beginPath(); ctx.arc(cx - dx, cy, r, a0, a0 + .9); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx + dx, cy, r, a0 + Math.PI, a0 + Math.PI + .9); ctx.stroke();

    var gx = cx + dx, gy = cy - r - 6 * k;
    var gw = 15 * k, gh = 20 * k;
    ctx.beginPath();
    ctx.moveTo(gx - gw, gy - gh * .25);
    ctx.lineTo(gx - gw * .55, gy - gh * .8);
    ctx.lineTo(gx + gw * .55, gy - gh * .8);
    ctx.lineTo(gx + gw, gy - gh * .25);
    ctx.lineTo(gx, gy + gh * .75);
    ctx.closePath();
    var gg = ctx.createLinearGradient(gx - gw, gy - gh, gx + gw, gy + gh);
    gg.addColorStop(0, '#f9f6ee');
    gg.addColorStop(.5, '#dfeaf2');
    gg.addColorStop(1, '#b7cfdd');
    ctx.fillStyle = gg; ctx.fill();
    ctx.strokeStyle = '#9db3c0'; ctx.lineWidth = 1.5 * k; ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(gx - gw, gy - gh * .25); ctx.lineTo(gx + gw, gy - gh * .25);
    ctx.moveTo(gx - gw * .55, gy - gh * .8); ctx.lineTo(gx - gw * .3, gy - gh * .25);
    ctx.moveTo(gx + gw * .55, gy - gh * .8); ctx.lineTo(gx + gw * .3, gy - gh * .25);
    ctx.moveTo(gx - gw * .3, gy - gh * .25); ctx.lineTo(gx, gy + gh * .75);
    ctx.moveTo(gx + gw * .3, gy - gh * .25); ctx.lineTo(gx, gy + gh * .75);
    ctx.strokeStyle = 'rgba(157,179,192,.7)'; ctx.lineWidth = 1 * k; ctx.stroke();

    var ps = 1 + Math.sin(now * .006) * .25;
    estrella(gx, gy - gh, 12 * k * ps, '#fdf6df', 1);
  }

  /* ---------- ramos (flores amarillas / mamá) ---------- */
  var CFG_RAMO = {
    flores: {
      tallo: '#7c8f45', talloGrosor: 5, cabecera: 54, tipo: 'tulipan',
      cabezas: ['#f0d478', '#e8c84a', '#f5e08c', '#e0b73e', '#f0d478', '#e8c84a', '#f5e08c', '#e0b73e', '#f5e08c'],
      bordes: '#c49220',
      cono: '#ecdc9e', conoBorde: '#c9ab5e', cinta: '#c49220',
      chispa: '#f0d478',
      mariposaA: '#e8a13c', mariposaB: '#f5d9a0'
    },
    madre: {
      tallo: '#7c8f45', talloGrosor: 4.5, cabecera: 40, tipo: 'margarita',
      cabezas: ['#f2c7d6', '#eab7cb', '#f7d9e3', '#e4a9c0', '#f2c7d6', '#eab7cb', '#f7d9e3', '#e4a9c0', '#f7d9e3'],
      bordes: '#d495ae', centros: '#c9779a',
      cono: '#f2e2e4', conoBorde: '#dcb9c0', cinta: '#b04a6e',
      chispa: '#f2c7d6',
      mariposaA: '#d487a8', mariposaB: '#f4dbe6'
    },
    tallos: [
      { dir: -1.25, len: .62, curva: -.12, retraso: .12 },
      { dir: -.90, len: .80, curva: -.08, retraso: .07 },
      { dir: -.60, len: .95, curva: -.05, retraso: .04 },
      { dir: -.30, len: .85, curva: -.03, retraso: .02 },
      { dir:  0.00, len: 1.00, curva:  0.00, retraso: 0 },
      { dir:  .30, len: .88, curva:  .03, retraso: .03 },
      { dir:  .60, len: .97, curva:  .05, retraso: .05 },
      { dir:  .90, len: .78, curva:  .08, retraso: .09 },
      { dir: 1.25, len: .60, curva:  .12, retraso: .13 }
    ]
  };

  function tulipan(x, y, s, ang, relleno, borde) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(ang);
    var k = s / 60;
    ctx.scale(k, k);
    ctx.translate(-50, -40);
    ctx.beginPath();
    ctx.moveTo(31, 18); ctx.lineTo(31, 42);
    ctx.quadraticCurveTo(31, 58, 50, 60);
    ctx.quadraticCurveTo(69, 58, 69, 42);
    ctx.lineTo(69, 18); ctx.lineTo(58, 30); ctx.lineTo(50, 16); ctx.lineTo(42, 30);
    ctx.closePath();
    ctx.fillStyle = relleno; ctx.fill();
    ctx.strokeStyle = borde; ctx.lineWidth = 3.5; ctx.stroke();
    ctx.restore();
  }

  function margarita(x, y, s, relleno, centro, borde) {
    ctx.save();
    ctx.translate(x, y);
    for (var i = 0; i < 8; i++) {
      ctx.save();
      ctx.rotate(i * Math.PI / 4);
      ctx.beginPath();
      ctx.ellipse(0, -s * .62, s * .26, s * .5, 0, 0, Math.PI * 2);
      ctx.fillStyle = relleno; ctx.fill();
      ctx.strokeStyle = borde; ctx.lineWidth = Math.max(1.2, s * .05); ctx.stroke();
      ctx.restore();
    }
    ctx.beginPath(); ctx.arc(0, 0, s * .3, 0, Math.PI * 2);
    ctx.fillStyle = centro; ctx.fill();
    ctx.restore();
  }

  function tallo(x0, y0, x1, y1, curva, progreso, color, grosor) {
    var p0 = { x: x0, y: y0 };
    var p1 = { x: (x0 + x1) / 2 + curva, y: (y0 + y1) / 2 };
    var p2 = { x: x1, y: y1 };
    var pasos = 22;
    var hasta = Math.max(1, Math.round(pasos * progreso));
    ctx.strokeStyle = color; ctx.lineWidth = grosor; ctx.lineCap = 'round';
    ctx.beginPath();
    var pt = qp(p0, p1, p2, 0);
    ctx.moveTo(pt.x, pt.y);
    for (var i = 1; i <= hasta; i++) {
      pt = qp(p0, p1, p2, i / pasos);
      ctx.lineTo(pt.x, pt.y);
    }
    ctx.stroke();
    return qp(p0, p1, p2, hasta / pasos);
  }

  function hoja(x, y, ang, len, color) {
    if (len <= 1) return;
    ctx.save();
    ctx.translate(x, y); ctx.rotate(ang);
    ctx.globalAlpha = .8;
    ctx.beginPath();
    ctx.ellipse(len * .5, 0, len * .5, len * .16, 0, 0, Math.PI * 2);
    ctx.fillStyle = color; ctx.fill();
    ctx.restore();
    ctx.globalAlpha = 1;
  }

  function lazo(x, y, r, color) {
    ctx.save();
    ctx.translate(x, y);
    ctx.strokeStyle = color; ctx.fillStyle = color;
    ctx.lineWidth = Math.max(3, r * .15); ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.bezierCurveTo(-r, -r * .8, -r * 1.1, r * .4, -r * .15, r * .12);
    ctx.moveTo(0, 0);
    ctx.bezierCurveTo(r, -r * .8, r * 1.1, r * .4, r * .15, r * .12);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, r * .1);
    ctx.quadraticCurveTo(-r * .4, r * .6, -r * .55, r * 1.05);
    ctx.moveTo(0, r * .1);
    ctx.quadraticCurveTo(r * .35, r * .65, r * .6, r * 1.0);
    ctx.lineWidth = Math.max(2, r * .12);
    ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 0, r * .16, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function mariposa(now, cx, cy, R, c1, c2) {
    var t = now * .001;
    var x = cx + Math.cos(t * .7) * R;
    var y = cy + Math.sin(t * 1.35) * R * .4 - 12;
    var flap = Math.abs(Math.sin(now * .013));
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(Math.cos(t * .7) * .5);
    ctx.fillStyle = c1;
    ctx.beginPath(); ctx.ellipse(-(4 * flap + 3), -3, 7 * flap + 1.5, 5.5, -.4, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse( (4 * flap + 3), -3, 7 * flap + 1.5, 5.5,  .4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = c2;
    ctx.beginPath(); ctx.ellipse(-(3 * flap + 2), 4, 5 * flap + 1, 4, -.2, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse( (3 * flap + 2), 4, 5 * flap + 1, 4,  .2, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#4a3a28';
    ctx.beginPath(); ctx.ellipse(0, 0, 1.6, 6.5, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function ramo(now, cfg) {
    var t = clamp((now - t0) / 2000, 0, 1);
    var cx = W / 2;
    var baseY = clamp(H * .60, 220, H - 110);
    var alto = Math.min(H * .34, 260);
    var abanico = Math.min(W * .4, 205);

    sombra(cx, baseY + 42, abanico * .55 * clamp(t * 1.2, 0, 1));

    ctx.save();
    ctx.translate(cx, baseY);
    ctx.rotate(Math.sin(now * .0011) * .03);

    for (var i = 0; i < CFG_RAMO.tallos.length; i++) {
      var f = CFG_RAMO.tallos[i];
      var tx = Math.sin(f.dir) * abanico * f.len;
      var ty = -Math.cos(f.dir) * alto * f.len - alto * .18;
      var prog = easeOut(clamp(t * 1.35 - f.retraso, 0, 1));
      var tip = tallo(0, 0, tx, ty, f.curva * alto, prog, cfg.tallo, cfg.talloGrosor);

      var bloom = clamp((t - .45 - f.retraso * .25) / .4, 0, 1);
      if (bloom > 0) {
        var s = cfg.cabecera * (0.2 + 0.8 * easeBack(bloom));
        var ang = f.dir * .8 + Math.sin(now * .0013 + i * 1.7) * .05;
        if (cfg.tipo === 'tulipan') tulipan(tip.x, tip.y, s, ang, cfg.cabezas[i % cfg.cabezas.length], cfg.bordes);
        else margarita(tip.x, tip.y, s, cfg.cabezas[i % cfg.cabezas.length], cfg.centros, cfg.bordes);
      }
    }

    var aG = clamp((t - .7) / .3, 0, 1);
    if (aG > 0) {
      ctx.globalAlpha = aG * .9;
      for (var g = 0; g < 6; g++) {
        var ga = -Math.PI / 2 + (g - 2.5) * .32;
        var gx = Math.cos(ga) * abanico * .62;
        var gy = -alto * .62 - Math.sin(ga) * alto * .18;
        ctx.fillStyle = '#fffdf2';
        for (var d = 0; d < 3; d++) {
          ctx.beginPath();
          ctx.arc(gx + (d - 1) * 5, gy + (d % 2) * 4, 2.6, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
    }

    if (t > .5) {
      var aH = clamp((t - .5) / .4, 0, 1);
      hoja(-abanico * .48, -alto * .36, -1.05, alto * .34 * aH, cfg.tallo);
      hoja( abanico * .48, -alto * .32,  1.05, alto * .30 * aH, cfg.tallo);
      hoja(-abanico * .2, -alto * .5, -1.25, alto * .2 * aH, cfg.tallo);
      hoja( abanico * .2, -alto * .48,  1.25, alto * .18 * aH, cfg.tallo);
    }

    var aC = clamp((t - .72) / .28, 0, 1);
    if (aC > 0) {
      ctx.globalAlpha = aC;
      var cw = abanico * .62, chT = alto * .34;
      ctx.beginPath();
      ctx.moveTo(-cw, -chT);
      ctx.quadraticCurveTo(-cw * .3, 10, -cw * .28, 28);
      ctx.lineTo(cw * .28, 28);
      ctx.quadraticCurveTo(cw * .3, 10, cw, -chT);
      ctx.closePath();
      ctx.fillStyle = cfg.cono; ctx.fill();
      ctx.strokeStyle = cfg.conoBorde; ctx.lineWidth = 2; ctx.stroke();
      lazo(0, 28, abanico * .28, cfg.cinta);
      ctx.globalAlpha = 1;
    }
    ctx.restore();

    chispitas(now, cx, baseY - alto * .55, abanico * .95, 7, cfg.chispa);
    mariposa(now, cx, baseY - alto * .62, abanico * .95, cfg.mariposaA, cfg.mariposaB);
  }

  /* ---------- pastel con regalos (cumpleaños) ---------- */
  function llama(x, y, s) {
    var g = ctx.createRadialGradient(x, y, 0, x, y, s * 3.4);
    g.addColorStop(0, 'rgba(255,200,80,.5)');
    g.addColorStop(1, 'rgba(255,200,80,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x, y, s * 3.4, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x, y - s);
    ctx.quadraticCurveTo(x + s * .85, y - s * .1, x, y + s * .6);
    ctx.quadraticCurveTo(x - s * .85, y - s * .1, x, y - s);
    ctx.fillStyle = '#f5b73a'; ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x, y - s * .4);
    ctx.quadraticCurveTo(x + s * .3, y, x, y + s * .38);
    ctx.quadraticCurveTo(x - s * .3, y, x, y - s * .4);
    ctx.fillStyle = '#fff3c4'; ctx.fill();
  }

  function dibujarGlobo(x, y, r, color, alpha) {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = 'rgba(55,40,28,.35)'; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(x, y + r * 1.25);
    ctx.quadraticCurveTo(x + 6, y + r * 1.25 + 30, x - 2, y + r * 1.25 + 56);
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(x, y, r * .82, r, 0, 0, Math.PI * 2);
    ctx.fillStyle = color; ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x, y + r);
    ctx.lineTo(x - 5, y + r + 8);
    ctx.lineTo(x + 5, y + r + 8);
    ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.ellipse(x - r * .3, y - r * .35, r * .18, r * .3, -.5, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.fill();
    ctx.restore();
  }

  var GLOBOS_AMB = [
    { u: .10, v: 34, r: 24, c: '#e05c4b' },
    { u: .24, v: 26, r: 30, c: '#5b8bd4' },
    { u: .76, v: 30, r: 27, c: '#3f9d8a' },
    { u: .90, v: 38, r: 22, c: '#d473b0' },
    { u: .50, v: 22, r: 18, c: '#e8b23a' }
  ];

  function nivelPastel(cx, yTop, w, h, relleno, glaseado) {
    for (var d = 0; d < 6; d++) {
      var dx = -w / 2 + w * (d + .5) / 6;
      var dl = 7 + ((d * 37) % 13);
      ctx.strokeStyle = glaseado;
      ctx.lineWidth = w * .075; ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(cx + dx, yTop + 3);
      ctx.lineTo(cx + dx, yTop + 3 + dl);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.moveTo(cx - w / 2, yTop);
    ctx.lineTo(cx - w / 2, yTop + h);
    ctx.quadraticCurveTo(cx, yTop + h + 8, cx + w / 2, yTop + h);
    ctx.lineTo(cx + w / 2, yTop);
    ctx.closePath();
    ctx.fillStyle = relleno; ctx.fill();
    ctx.strokeStyle = 'rgba(55,40,28,.28)'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - w / 2, yTop + 2);
    ctx.lineTo(cx + w / 2, yTop + 2);
    ctx.strokeStyle = glaseado; ctx.lineWidth = 5; ctx.stroke();
    var spr = ['#e05c4b', '#5b8bd4', '#3f9d8a', '#d473b0', '#8bc34a'];
    for (var i = 0; i < 8; i++) {
      var px = cx - w * .38 + ((i * 53) % 100) / 100 * (w * .76);
      var py = yTop + h * .3 + ((i * 29) % 100) / 100 * (h * .55);
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate((i * 1.7) % 3.14);
      ctx.fillStyle = spr[i % spr.length];
      ctx.fillRect(-3, -1.4, 6, 2.8);
      ctx.restore();
    }
  }

  function pastel(now) {
    var t = clamp((now - t0) / 1700, 0, 1);
    var s = easeOut(t);
    var cx = W / 2;
    var base = clamp(H * .58, 230, H - 120);
    var w1 = Math.min(W * .52, 320) * s;
    if (w1 < 10) return;
    var h1 = w1 * .24;
    var w2 = w1 * .66, h2 = w1 * .18;

    for (var b = 0; b < GLOBOS_AMB.length; b++) {
      var B = GLOBOS_AMB[b];
      var ciclo = H + 220;
      var by = H + 70 - ((now * (.028 + b * .007) + b * 240) % ciclo);
      var bx = W * B.u + Math.sin(now * .0012 + b * 2) * 12;
      var a = clamp((H - by) / 130, 0, .85) * clamp((by - 30) / 100, 0, 1);
      if (a > 0) dibujarGlobo(bx, by, B.r, B.c, a);
    }

    sombra(cx, base + 18, w1 * .62 * s);

    ctx.beginPath();
    ctx.ellipse(cx, base + 8, w1 * .66, 13 * s, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#efe6cd'; ctx.fill();
    ctx.strokeStyle = 'rgba(55,40,28,.25)'; ctx.lineWidth = 1.5; ctx.stroke();

    nivelPastel(cx, base - h1, w1, h1, '#f9f2da', '#e8b23a');
    nivelPastel(cx, base - h1 - 5 - h2, w2, h2, '#fdf7e6', '#f0c65a');

    if (t > .5) {
      var vCol = ['#5b8bd4', '#e05c4b', '#3f9d8a', '#d473b0', '#e8b23a', '#5b8bd4', '#e05c4b'];
      var nV = 7, span = w2 * .8;
      var yTopC = base - h1 - 5 - h2;
      for (var i = 0; i < nV; i++) {
        var vx = cx - span / 2 + (span / (nV - 1)) * i;
        var cvA = clamp((t - .5 - i * .04) / .3, 0, 1);
        var altoV = 27 * cvA;
        ctx.strokeStyle = vCol[i];
        ctx.lineWidth = 5; ctx.lineCap = 'butt';
        ctx.beginPath(); ctx.moveTo(vx, yTopC + 2); ctx.lineTo(vx, yTopC - altoV); ctx.stroke();
        ctx.strokeStyle = '#6b5236'; ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.moveTo(vx, yTopC - altoV); ctx.lineTo(vx, yTopC - altoV - 4); ctx.stroke();
        var fl = 1 + Math.sin(now * .02 + i * 2.1) * .2;
        if (cvA > .3) llama(vx, yTopC - altoV - 8 * fl, 7 * fl * cvA);
      }
    }

    posicionarRegalos(cx, base, w1);
  }

  /* ---------- regalos clicables ---------- */
  function svgRegalo(caja, tapa, cinta, cintaOsc) {
    return '<svg viewBox="0 0 100 100" aria-hidden="true">' +
      '<rect x="16" y="42" width="68" height="48" rx="5" fill="' + caja + '"/>' +
      '<rect x="10" y="30" width="80" height="16" rx="5" fill="' + tapa + '"/>' +
      '<rect x="44" y="30" width="12" height="60" fill="' + cinta + '"/>' +
      '<ellipse cx="34" cy="21" rx="14" ry="8" fill="none" stroke="' + cinta + '" stroke-width="6" transform="rotate(-18 34 21)"/>' +
      '<ellipse cx="66" cy="21" rx="14" ry="8" fill="none" stroke="' + cinta + '" stroke-width="6" transform="rotate(18 66 21)"/>' +
      '<circle cx="50" cy="26" r="7" fill="' + cintaOsc + '"/>' +
      '<rect x="16" y="42" width="68" height="48" rx="5" fill="none" stroke="rgba(55,40,28,.2)" stroke-width="1.5"/>' +
      '<rect x="10" y="30" width="80" height="16" rx="5" fill="none" stroke="rgba(55,40,28,.2)" stroke-width="1.5"/>' +
      '</svg>';
  }

  function crearRegalos() {
    if (regaloIzq || !escena) return;

    regaloIzq = document.createElement('button');
    regaloIzq.type = 'button';
    regaloIzq.className = 'celeb-regalo';
    regaloIzq.setAttribute('aria-label', 'Regalo sorpresa: picca picca y globos');
    regaloIzq.title = '¡Tócame!';
    regaloIzq.innerHTML = svgRegalo('#c94f43', '#a83a30', '#f0d478', '#d9b64e');

    regaloDer = document.createElement('button');
    regaloDer.type = 'button';
    regaloDer.className = 'celeb-regalo';
    regaloDer.setAttribute('aria-label', 'Regalo sorpresa: picca picca y globos');
    regaloDer.title = '¡Tócame!';
    regaloDer.innerHTML = svgRegalo('#2e8b7f', '#237065', '#f0e0a0', '#d9c478');

    hintRegalos = document.createElement('p');
    hintRegalos.className = 'celeb-hint';
    hintRegalos.textContent = 'Toca los regalos';

    regaloIzq.style.display = 'none';
    regaloDer.style.display = 'none';
    hintRegalos.style.display = 'none';

    regaloIzq.addEventListener('click', alTocarRegalo(regaloIzq));
    regaloDer.addEventListener('click', alTocarRegalo(regaloDer));

    escena.appendChild(regaloIzq);
    escena.appendChild(regaloDer);
    escena.appendChild(hintRegalos);
  }

  function posicionarRegalos(cx, base, w1) {
    if (!regaloIzq || !regaloDer) return;
    var w = clamp(w1 * .3, 60, 108);
    var sep = w1 * .68 + w * .45;
    var top = clamp(base - w * .85, H * .3, H - w - 12);

    regaloIzq.style.display = '';
    regaloDer.style.display = '';
    regaloIzq.style.width = w + 'px';
    regaloDer.style.width = w + 'px';
    regaloIzq.style.left = clamp(cx - sep - w / 2, 6, W - w - 6) + 'px';
    regaloDer.style.left = clamp(cx + sep - w / 2, 6, W - w - 6) + 'px';
    regaloIzq.style.top = top + 'px';
    regaloDer.style.top = top + 'px';

    if (hintRegalos) {
      hintRegalos.style.display = '';
      hintRegalos.style.left = cx + 'px';
      hintRegalos.style.top = (base + 26) + 'px';
    }
  }

  function ocultarRegalos() {
    if (regaloIzq) regaloIzq.style.display = 'none';
    if (regaloDer) regaloDer.style.display = 'none';
    if (hintRegalos) hintRegalos.style.display = 'none';
  }

  function alTocarRegalo(btn) {
    return function () {
      btn.classList.remove('rebote');
      void btn.offsetWidth;
      btn.classList.add('rebote');

      var r = btn.getBoundingClientRect();
      var x = r.left + r.width / 2;
      var y = r.top + r.height / 2;

      explotarConfeti(x, y);
      soltarGlobos(x, y, 3);

      /* ¡POP! de corcho + chispa (nuevo sonido del regalo) */
      if (App.AudioFX && typeof App.AudioFX.pop === 'function') {
        App.AudioFX.pop();
      } else if (App.AudioFX) {
        var notas = [523.25, 587.33, 659.25, 783.99];
        App.AudioFX.nota(notas[(Math.random() * notas.length) | 0]);
      }

      if (!corriendo) {
        corriendo = true;
        lastNow = performance.now();
        if (raf) cancelAnimationFrame(raf);
        raf = requestAnimationFrame(frame);
      }
    };
  }

  function explotarConfeti(x, y) {
    var colores = ['#e05c4b', '#e8b23a', '#3f9d8a', '#5b8bd4', '#d473b0', '#8bc34a', '#f0d478'];
    for (var i = 0; i < 32; i++) {
      var a = Math.random() * Math.PI * 2;
      var v = 150 + Math.random() * 280;
      confeti.push({
        x: x, y: y,
        vx: Math.cos(a) * v,
        vy: Math.sin(a) * v - 170,
        rot: Math.random() * 6.28,
        vr: (Math.random() - .5) * 12,
        w: 4 + Math.random() * 5,
        h: 7 + Math.random() * 7,
        color: colores[i % colores.length],
        vida: 1.2 + Math.random() * .5,
        edad: 0
      });
    }
    if (confeti.length > 140) confeti.splice(0, confeti.length - 140);
  }

  function soltarGlobos(x, y, n) {
    var colores = ['#e05c4b', '#5b8bd4', '#3f9d8a', '#d473b0', '#e8b23a'];
    for (var i = 0; i < n; i++) {
      globosUsuario.push({
        x: x + (i - (n - 1) / 2) * 26 + (Math.random() - .5) * 10,
        y: y - 10,
        vy: 95 + Math.random() * 55,
        r: 17 + Math.random() * 8,
        color: colores[(Math.random() * colores.length) | 0],
        fase: Math.random() * 6.28,
        edad: 0
      });
    }
    if (globosUsuario.length > 14) globosUsuario.splice(0, globosUsuario.length - 14);
  }

  function pasoParticulas(dt) {
    var i;
    for (i = confeti.length - 1; i >= 0; i--) {
      var c = confeti[i];
      c.edad += dt;
      if (c.edad >= c.vida) { confeti.splice(i, 1); continue; }
      c.vy += 620 * dt;
      c.vx *= .995;
      c.x += c.vx * dt;
      c.y += c.vy * dt;
      c.rot += c.vr * dt;
    }
    for (i = globosUsuario.length - 1; i >= 0; i--) {
      var g = globosUsuario[i];
      g.edad += dt;
      g.y -= g.vy * dt;
      g.x += Math.sin(g.edad * 2.4 + g.fase) * 22 * dt;
      if (g.y < -90) globosUsuario.splice(i, 1);
    }
  }

  function dibujarParticulas() {
    var i;
    for (i = 0; i < confeti.length; i++) {
      var c = confeti[i];
      ctx.save();
      ctx.globalAlpha = clamp(1 - c.edad / c.vida, 0, 1);
      ctx.translate(c.x, c.y);
      ctx.rotate(c.rot);
      ctx.fillStyle = c.color;
      ctx.fillRect(-c.w / 2, -c.h / 2, c.w, c.h);
      ctx.restore();
    }
    for (i = 0; i < globosUsuario.length; i++) {
      var g = globosUsuario[i];
      var a = clamp(g.edad / .35, 0, 1);
      dibujarGlobo(g.x, g.y, g.r * (.5 + .5 * a), g.color, a);
    }
  }

  /* ---------- despacho y bucle ---------- */
  function dibujarFrame(now) {
    ctx.clearRect(0, 0, W, H);
    try {
      if (tema === 'flores') ramo(now, CFG_RAMO.flores);
      else if (tema === 'madre') ramo(now, CFG_RAMO.madre);
      else if (tema === 'cumple') pastel(now);
      else if (tema === 'teextrano') aviones(now);
      else if (tema === 'aniversario') anillos(now);
      else corazon(now);
    } catch (e) { /* el regalo jamás rompe la escena */ }
    dibujarParticulas();
  }

  function frame(now) {
    if (!corriendo) return;
    if (!escena || !escena.classList.contains('active')) { parar(); return; }
    var dt = clamp((now - lastNow) / 1000, 0, .05);
    lastNow = now;
    pasoParticulas(dt);
    dibujarFrame(now);

    if (REDUCED && confeti.length === 0 && globosUsuario.length === 0) {
      corriendo = false;
      if (raf) { cancelAnimationFrame(raf); raf = null; }
      dibujarFrame(t0 + 6000);
      return;
    }
    raf = requestAnimationFrame(frame);
  }

  function parar() {
    corriendo = false;
    if (raf) { cancelAnimationFrame(raf); raf = null; }
    if (ctx && W) ctx.clearRect(0, 0, W, H);
    if (corazonEstatico) corazonEstatico.style.display = displayPrevio;
    ocultarRegalos();
    confeti = [];
    globosUsuario = [];
  }

  App.Celebracion = {
    arrancar: function (temaId) {
      if (!init()) return;
      tema = (App.Temas && App.Temas.validar) ? App.Temas.validar(temaId) : 'disculpa';
      redimensionar();
      t0 = performance.now();
      confeti = [];
      globosUsuario = [];

      if (!corazonEstatico) {
        corazonEstatico = escena.querySelector('.big-heart');
        if (corazonEstatico) displayPrevio = corazonEstatico.style.display || '';
      }
      if (corazonEstatico) corazonEstatico.style.display = 'none';

      ocultarRegalos();
      if (tema === 'cumple') {
        crearRegalos();
        if (hintRegalos) {
          hintRegalos.style.animation = 'none';
          void hintRegalos.offsetWidth;
          hintRegalos.style.animation = '';
        }
      }

      if (REDUCED) {
        corriendo = false;
        dibujarFrame(t0 + 6000);
        if (tema === 'cumple') posicionarRegalos(W / 2, clamp(H * .58, 230, H - 120), Math.min(W * .52, 320));
        return;
      }
      corriendo = true;
      lastNow = t0;
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(frame);
    },
    parar: parar
  };
})(window.App = window.App || {});