<?php
/* carta.php · GET ?id=codigo  |  ?id=codigo&editar=1&admin=hash
   - Sin id: sonda (¿hay PHP?).
   - Lectura: si la carta tiene estreno futuro → NO entrega los bloques:
     responde 'espera' con la fecha. El destinatario ve la pantalla de
     cuenta regresiva. El hash admin jamás sale del servidor.
   - Edición (remitente): verifica la contraseña y entrega la carta
     completa aunque aún no sea la fecha (para revisarla). */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function responder($ok, $extra = array(), $codigo = 200) {
  http_response_code($codigo);
  echo json_encode(array_merge(array('ok' => $ok), $extra));
  exit;
}

if (!isset($_GET['id'])) responder(false, array('error' => 'falta id'));

 $id = preg_replace('/[^a-zA-Z0-9]/', '', (string)$_GET['id']);
if (strlen($id) < 6 || strlen($id) > 20) responder(false, array('error' => 'id inválido'));

 $archivo = __DIR__ . '/../data/cartas/' . $id . '.json';
if (!is_file($archivo)) responder(false, array('error' => 'carta no encontrada'));

 $datos = json_decode(file_get_contents($archivo), true);
if (!is_array($datos) || empty($datos['clave'])) {
  responder(false, array('error' => 'carta corrupta'));
}

/* ---- modo edición: contraseña verificada ANTES de entregar nada ---- */
if (isset($_GET['editar'])) {
  $adminGuardada = !empty($datos['admin']) ? strtolower($datos['admin']) : '';
  $adminDada = isset($_GET['admin']) ? strtolower((string)$_GET['admin']) : '';
  $esHash = function ($s) { return is_string($s) && preg_match('/^[a-fA-F0-9]{64}$/', $s) === 1; };

  if ($adminGuardada === '') responder(false, array('error' => 'Esta carta no puede editarse.'), 403);

  if ($esHash($adminDada) && hash_equals($adminGuardada, $adminDada)) {
    unset($datos['admin']);
    responder(true, array('datos' => $datos));   /* remitente: carta completa */
  }
  usleep(400000);
  responder(false, array('error' => 'Contraseña de editor incorrecta.'), 403);
}

/* ---- modo lectura: ¿hay estreno en el futuro? ---- */
if (!empty($datos['estreno']) && (int)$datos['estreno'] > time()) {
  responder(true, array(
    'espera' => true,
    'estreno' => (int)$datos['estreno'],
    'para' => isset($datos['para']) ? $datos['para'] : '',
    'tema' => isset($datos['tema']) ? $datos['tema'] : 'disculpa'
  ));
  /* sin bloques, sin pista: la carta no viaja hasta su día */
}

unset($datos['admin']);
responder(true, array('datos' => $datos));