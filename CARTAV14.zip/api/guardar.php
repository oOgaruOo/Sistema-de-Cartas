<?php
/* guardar.php · POST JSON:
   { id?, para, de, despedida, pista, clave(hash|''), admin(hash), texto,
     tema?, test?, estreno? ('YYYY-MM-DDTHH:MM' | '') }
   - Sin id → CREA carta nueva (máx. 5/IP/hora con poda).
   - Con id → EDITA (exige contraseña de editor; conserva 'creada' y 'tema').
   - estreno: fecha opcional desde la cual el destinatario puede abrir
     la carta. El remitente (con su contraseña de editor) SIEMPRE entra.
   - La respuesta informa 'restantes' y valida el formato de estreno. */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function responder($ok, $extra = array(), $codigo = 200) {
  http_response_code($codigo);
  echo json_encode(array_merge(array('ok' => $ok), $extra));
  exit;
}

/* ══════════════════════════════════════════════════════════════
   PALABRA DE MODO TEST · para generar el hash:
   En tu web: F12 → Consola →
     App.U.sha256Hex(App.U.normalizarClave('TU PALABRA AQUÍ'))
   ══════════════════════════════════════════════════════════════ */
 $TEST_HASH = 'f0e4c2f76c58916ec258f24e18d741c1d5e0a3d0b1e1a8c9d7b6a5f4e3d2c1b0a';

 $LIMITE_IP_HORA = 5;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(false, array('error' => 'Método no permitido'), 405);

 $crudo = file_get_contents('php://input');
if (strlen($crudo) > 20000) responder(false, array('error' => 'Datos demasiado grandes'), 413);

 $e = json_decode($crudo, true);
if (!is_array($e)) responder(false, array('error' => 'Datos inválidos'), 400);

function esHash($s) { return is_string($s) && preg_match('/^[a-fA-F0-9]{64}$/', $s) === 1; }
function txt($v, $n) {
  $s = trim((string)$v);
  return function_exists('mb_substr') ? mb_substr($s, 0, $n, 'UTF-8') : substr($s, 0, $n);
}

/* estreno: '' (sin fecha) o 'YYYY-MM-DDTHH:MM' válido y futuro tolerante.
   Se guarda como epoch UTC para comparar sin ambigüedad. */
function normalizarEstreno($v) {
  $s = trim((string)$v);
  if ($s === '') return 0;
  $t = strtotime($s);
  if ($t === false || $t === -1 || $t < 946684800) return -1;   /* fecha imposible */
  return $t;
}

 $TEMAS_PERMITIDOS = array('disculpa', 'teextrano', 'cumple', 'madre', 'aniversario', 'flores');

 $esTest = isset($e['test']) && esHash((string)$e['test']) &&
          hash_equals(strtolower($TEST_HASH), strtolower((string)$e['test']));

 $dir = __DIR__ . '/../data/cartas';
if (!is_dir($dir)) @mkdir($dir, 0755, true);

/* ---------- anti-spam ---------- */
 $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'x';
 $rlf = __DIR__ . '/../data/rl.json';
 $rl = is_file($rlf) ? (json_decode(file_get_contents($rlf), true) ?: array()) : array();
 $ahora = time();

foreach ($rl as $ipVieja => $ts) {
  if (!is_array($ts)) { unset($rl[$ipVieja]); continue; }
  $vivos = array();
  foreach ($ts as $t) if ($t > $ahora - 3600) $vivos[] = $t;
  if ($vivos) $rl[$ipVieja] = $vivos; else unset($rl[$ipVieja]);
}

 $recientes = isset($rl[$ip]) ? $rl[$ip] : array();
 $restantes = max(0, $LIMITE_IP_HORA - count($recientes));

/* ---------- ¿crear o actualizar? ---------- */
 $id = '';
if (!empty($e['id'])) $id = preg_replace('/[^a-zA-Z0-9]/', '', (string)$e['id']);

 $actual = array();

if ($id !== '') {
  $archivo = $dir . '/' . $id . '.json';
  if (!is_file($archivo)) responder(false, array('error' => 'Carta no encontrada.'), 404);
  $actual = json_decode(file_get_contents($archivo), true);
  $adminGuardada = (is_array($actual) && !empty($actual['admin'])) ? strtolower($actual['admin']) : '';
  if ($adminGuardada === '') responder(false, array('error' => 'Esta carta no puede editarse.'), 403);
  $adminDada = isset($e['admin']) ? strtolower((string)$e['admin']) : '';
  if (!esHash($adminDada) || !hash_equals($adminGuardada, $adminDada)) {
    usleep(400000);
    responder(false, array('error' => 'La contraseña de editor no coincide.'), 403);
  }
  $actualClave = !empty($actual['clave']) ? $actual['clave'] : '';
  $infoFinal = array('restantes' => $restantes, 'test' => false);
} else {
  if (!$esTest) {
    if ($restantes <= 0) {
      usleep(400000);
      responder(false, array(
        'error' => 'Demasiadas cartas creadas desde esta conexión en la última hora. Inténtalo más tarde.',
        'restantes' => 0,
        'test' => false
      ), 429);
    }
    $rl[$ip] = array_merge($recientes, array($ahora));
    $restantes = $restantes - 1;
  }
  @file_put_contents($rlf, json_encode($rl), LOCK_EX);

  $intentos = 0;
  do { $id = bin2hex(random_bytes(5)); $intentos++; }
  while (is_file($dir . '/' . $id . '.json') && $intentos < 25);
  $actualClave = '';
  $infoFinal = array('restantes' => $restantes, 'test' => $esTest);
}

 $archivo = $dir . '/' . $id . '.json';

/* ---------- campos ---------- */
 $admin = isset($e['admin']) ? strtolower((string)$e['admin']) : '';
if (!esHash($admin)) responder(false, array('error' => 'Falta la contraseña de editor.'), 400);

 $clave = isset($e['clave']) ? (string)$e['clave'] : '';
if (esHash($clave)) $claveFinal = strtolower($clave);
elseif ($clave === '' && $actualClave !== '') $claveFinal = $actualClave;
else responder(false, array('error' => 'La palabra secreta no se recibió correctamente.'), 400);

 $tema = 'disculpa';
if (isset($e['tema']) && in_array((string)$e['tema'], $TEMAS_PERMITIDOS, true)) $tema = (string)$e['tema'];
elseif ($id !== '' && !empty($actual['tema'])) $tema = $actual['tema'];

 $creada = date('c');
if ($id !== '' && !empty($actual['creada'])) $creada = $actual['creada'];

/* estreno: vacío = 0 (sin restricción); inválido = error;
   al editar sin enviar el campo, se conserva el actual */
 $estreno = 0;
if (isset($e['estreno'])) {
  $estreno = normalizarEstreno($e['estreno']);
  if ($estreno === -1) responder(false, array('error' => 'La fecha de estreno no es válida (usa AAAA-MM-DD HH:MM).'), 400);
} elseif ($id !== '' && isset($actual['estreno'])) {
  $estreno = (int)$actual['estreno'];
}

/* ---------- texto → bloques ---------- */
 $texto = isset($e['texto']) ? (string)$e['texto'] : '';
 $largo = function_exists('mb_strlen') ? mb_strlen($texto) : strlen($texto);
if ($largo > 8000) responder(false, array('error' => 'La carta es demasiado larga (máx. 8000 caracteres).'), 400);

 $bloques = array();
foreach (preg_split('/\n\s*\n/u', trim($texto)) as $b) {
  $b = trim($b);
  if ($b === '') continue;
  if (preg_match('/^\*(.+)\*$/su', $b, $m)) $bloques[] = array('tipo' => 'enfasis', 'texto' => trim($m[1]));
  else $bloques[] = array('tipo' => 'parrafo', 'texto' => $b);
}
if (!count($bloques)) responder(false, array('error' => 'Escribe al menos un párrafo.'), 400);
if (count($bloques) > 40) responder(false, array('error' => 'La carta tiene demasiados párrafos (máx. 40).'), 400);
 $bloques[] = array('tipo' => 'firma');

 $datos = array(
  'para'      => txt(isset($e['para']) ? $e['para'] : '', 24),
  'de'        => txt(isset($e['de']) ? $e['de'] : '', 24),
  'clave'     => $claveFinal,
  'pista'     => txt(isset($e['pista']) ? $e['pista'] : '', 80),
  'admin'     => $admin,
  'tema'      => $tema,
  'creada'    => $creada,
  'estreno'   => $estreno,
  'despedida' => txt((isset($e['despedida']) && $e['despedida'] !== '') ? $e['despedida'] : 'Con todo mi corazón,', 60),
  'bloques'   => $bloques
);

 $ok = @file_put_contents($archivo, json_encode($datos, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
if ($ok === false)
  responder(false, array('error' => 'No se pudo escribir en el servidor: da permisos 775 a la carpeta data/cartas.'), 500);

responder(true, array_merge(array('id' => $id, 'clave' => $claveFinal), $infoFinal));