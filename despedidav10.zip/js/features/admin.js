/* ============================================================
   admin.js · v3 — editor de cartas de la plataforma
   Crea cartas nuevas y las edita (api/guardar.php).
   Entrega al creador: enlace para ella, directo y de edición.
   ============================================================ */
(function (App) {
  'use strict';

  var U = App.U;
  var montado = false;
  var phpOK = false;
  var editando = false;
  var cartaId = null;
  var datos = null;      /* datos actuales de la carta (sin admin) */
  var DOM = {};

  function base() {
    return location.origin + location.pathname.replace(/index\.html$/i, '').replace(/\/+$/, '') + '/';
  }

  /* bloques guardados → texto editable (sintaxis *énfasis*) */
  function bloquesATexto(bloques) {
    var out = [];
    (bloques || []).forEach(function (b) {
      if (b.tipo === 'parrafo') out.push(b.texto);
      else if (b.tipo === 'enfasis') out.push('*' + b.texto + '*');
    });
    return out.join('\n\n');
  }

  function msg(txt, tipo) {
    DOM.msg.textContent = txt || '';
    DOM.msg.className = 'admin-msg' + (tipo ? ' ' + tipo : '');
  }

  function copiar(btn, texto) {
    function listo() {
      var o = btn.textContent;
      btn.textContent = '¡Copiado!';
      setTimeout(function () { btn.textContent = o; }, 1600);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(texto).then(listo, function () { listo(); });
    } else listo();
  }

  function boton(texto, ghost, fn) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'btn btn-sm' + (ghost ? ' btn-ghost' : '');
    b.textContent = texto;
    b.addEventListener('click', fn);
    return b;
  }

  function filaEnlace(titulo, url, botones) {
    var fila = document.createElement('div');
    fila.className = 'admin-link';
    var t = document.createElement('p');
    t.className = 'admin-link-t'; t.textContent = titulo;
    var c = document.createElement('code');
    c.textContent = url;
    var cont = document.createElement('div');
    cont.className = 'admin-link-btns';
    botones.forEach(function (b) { cont.appendChild(boton(b[0], b[1], b[2])); });
    fila.appendChild(t); fila.appendChild(c); fila.appendChild(cont);
    return fila;
  }

  function mostrarEnlaces(id, hashClave, palabraEnClaro) {
    var zona = DOM.links;
    zona.innerHTML = '';
    zona.classList.remove('hide');

    var limpio  = base() + '?carta=' + id;
    var directo = base() + '?carta=' + id + '&k=' + hashClave;
    var editar  = base() + '?carta=' + id + '#admin';

    zona.appendChild(filaEnlace('Enlace para esa persona — digita la palabra secreta', limpio, [
      ['Copiar', false, function () { copiar(this, limpio); }],
      ['Probar', true, function () { location.href = limpio; }]
    ]));
    zona.appendChild(filaEnlace('Enlace directo — la carta se abre sola', directo, [
      ['Copiar', false, function () { copiar(this, directo); }],
      ['WhatsApp', true, function () {
        window.open('https://wa.me/?text=' + encodeURIComponent(
          'Hay algo que escribí para ti, y me gustaría que lo leyeras cuando tengas un momento tranquilo:\n' + directo), '_blank');
      }]
    ]));
    zona.appendChild(filaEnlace('Tu enlace para editar esta carta más adelante', editar, [
      ['Copiar', false, function () { copiar(this, editar); }]
    ]));

    var p = document.createElement('p');
    p.className = 'admin-recordar';
    p.innerHTML = palabraEnClaro
      ? 'Palabra secreta: <b>' + palabraEnClaro.replace(/[<>&]/g, '') + '</b> (mayúsculas y acentos no importan). Guárdala junto con tu enlace de edición.'
      : 'La palabra secreta no cambió: sigue siendo la que ya conocías.';
    zona.appendChild(p);
  }

  function montar() {
    DOM.form = U.$('adminForm');
    DOM.para = U.$('adminPara');
    DOM.de = U.$('adminDe');
    DOM.despedida = U.$('adminDespedida');
    DOM.texto = U.$('adminTexto');
    DOM.clave = U.$('adminClave');
    DOM.pista = U.$('adminPista');
    DOM.pass = U.$('adminPass');
    DOM.msg = U.$('adminMsg');
    DOM.links = U.$('adminLinks');
    DOM.sub = U.$('adminSub');
    DOM.notaClave = U.$('adminClaveNota');
    DOM.titulo = U.$('adminTitle');
    DOM.guardar = U.$('adminGuardar');
    DOM.idBadge = U.$('adminId');

    DOM.form.addEventListener('submit', function (e) {
      e.preventDefault();
      msg('');

      if (!phpOK) { msg('Este servidor no puede guardar cartas: se necesita un hosting con PHP (como InfinityFree).', 'error'); return; }

      var pass = U.normalizarClave(DOM.pass.value);
      var palabra = U.normalizarClave(DOM.clave.value);
      if (!pass) { msg('Escribe la contraseña de editor.', 'error'); return; }
      if (!palabra && !editando) { msg('Escribe la palabra secreta que la otra persona deberá digitar.', 'error'); return; }
      if (!DOM.texto.value.trim()) { msg('Escribe tu carta.', 'error'); return; }

      var payload = {
        para: DOM.para.value.trim().slice(0, 24),
        de: DOM.de.value.trim().slice(0, 24),
        despedida: DOM.despedida.value.trim().slice(0, 60),
        pista: DOM.pista.value.trim().slice(0, 80),
        clave: palabra ? U.sha256Hex(palabra) : '',
        admin: U.sha256Hex(pass),
        texto: DOM.texto.value
      };
      if (editando) payload.id = cartaId;

            var btn = DOM.guardar;
      if (btn.disabled) return;          /* evita el doble envío */
      btn.disabled = true;

      msg('Guardando…');
      App.Ajax.post('api/guardar.php', payload)
        .then(function (r) {
          if (!r || !r.ok) throw new Error((r && r.error) || 'respuesta inesperada');
          App.AudioFX.sello();

          if (!editando) {
            editando = true;
            cartaId = r.id;
            DOM.titulo.textContent = 'Editar carta';
            DOM.guardar.textContent = 'Guardar cambios';
            msg('¡Tu carta está lista! Envíale uno de los enlaces de abajo.', 'exito');
          } else {
            msg('Guardado. Los cambios ya están publicados.', 'exito');
          }
          datos = { para: payload.para, de: payload.de, pista: payload.pista };
          DOM.pass.value = '';
          DOM.clave.value = '';
          DOM.notaClave.textContent = 'Déjala vacía para mantener la actual.';
          DOM.idBadge.textContent = 'Código de esta carta: ' + cartaId;
          DOM.idBadge.classList.remove('hide');
          mostrarEnlaces(cartaId, r.clave, palabra);
        })
        .catch(function (e) { msg('No se pudo guardar: ' + e.message, 'error'); })
        .then(function () { btn.disabled = false; });   /* se reactiva siempre */
    });
  }

  App.Admin = {
    init: function (opts) {
      opts = opts || {};
      phpOK = !!opts.php;
      datos = opts.datos || null;
      cartaId = opts.id || null;
      editando = !!(opts.edicion && cartaId && datos && datos.bloques);

      if (!montado) { montar(); montado = true; }

      DOM.para.value = (datos && datos.para) || '';
      DOM.de.value = (datos && datos.de) || '';
      DOM.despedida.value = (datos && datos.despedida) || '';
      DOM.pista.value = (datos && datos.pista) || '';
      DOM.texto.value = editando ? bloquesATexto(datos.bloques) : '';
      DOM.clave.value = '';
      DOM.pass.value = '';
      DOM.links.classList.add('hide');
      DOM.links.innerHTML = '';
      DOM.msg.textContent = '';
      DOM.msg.className = 'admin-msg';

      if (editando) {
        DOM.titulo.textContent = 'Editar carta';
        DOM.guardar.textContent = 'Guardar cambios';
        DOM.notaClave.textContent = 'Déjala vacía para mantener la actual.';
        DOM.idBadge.textContent = 'Código de esta carta: ' + cartaId;
        DOM.idBadge.classList.remove('hide');
        DOM.sub.textContent = 'Ajusta lo que necesites: los cambios se publican al instante para quien abra el enlace.';
      } else {
        DOM.titulo.textContent = 'Escribe tu carta';
        DOM.guardar.textContent = 'Crear carta';
        DOM.notaClave.textContent = '';
        DOM.idBadge.classList.add('hide');
        DOM.sub.textContent = 'Escríbela con calma: al crearla recibirás los enlaces para enviarla (y uno secreto para editarla).';
      }
    }
  };
})(window.App = window.App || {});