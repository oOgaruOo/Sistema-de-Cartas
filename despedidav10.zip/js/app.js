/* ============================================================
   app.js · v5 FINAL — plataforma multi-cartas
   Rutas:
     /                      → landing (crear carta)
     ?carta=ID              → lectura (cerrojo + carta)
     ?carta=ID&k=HASH       → lectura directa (se abre sola)
     ?carta=ID#admin        → edición (contraseña de editor)
     #admin (sin carta)     → se ignora: siempre muestra la landing
   ============================================================ */
(function (App) {
  'use strict';

  var VERSION = 'plataforma multi-cartas · v5';

  var U = App.U;
  var ESCENAS = ['home', 'gate', 'cover', 'envelope', 'letter', 'question', 'forgiven', 'notyet', 'admin'];

  var config = null, contenido = null, privado = {};
  var ctx = { modo: 'inicio', id: null, k: null, phpOK: false, error: '' };
  var selloPuesto = false;
  var cerrojoMontado = false;

  var CONFIG_FALLBACK = {
    maquina: { baseMs: 24, varMs: 34, pausaComa: 170, pausaPunto: 340 },
    petalos: { emisionPorSegundo: 26, probCorazon: .22, duracionRafaga: 4.5 },
    polvo: { areaPorParticula: 26000, maximo: 58 }
  };
  var CONTENIDO_FALLBACK = {
    portada: {
      eyebrow: 'Una carta para pedir perdón',
      titulo: 'Lo siento<em>,</em>',
      subtitulo: 'Hay cosas que no caben en un mensaje de texto.<br>Esta merecía ser una <em>carta</em>.',
      hint: 'Toma un minuto. Vale la pena leerlo despacio.'
    },
    sobre: { eyebrow: 'Carta entregada a mano', hint: 'Toca el <em>sello de cera</em> para abrirla' },
    carta: {
      despedida: 'Con todo mi corazón,',
      bloques: [
        { tipo: 'parrafo', texto: 'Llevo días queriendo decirte esto. Lo ensayé mil veces en mi cabeza y, ahora que por fin me decido, ninguna palabra me parece suficiente. Aun así, aquí voy:' },
        { tipo: 'enfasis', texto: 'Lo siento.' },
        { tipo: 'parrafo', texto: 'Y no lo digo por decir, ni para salir del paso. Lo digo porque me duele lo que te hice, y porque callarlo sería fallarte una segunda vez.' },
        { tipo: 'firma' }
      ]
    },
    pregunta: {
      titulo: '¿Me perdonas?',
      subtitulo: 'Puedes responder con la verdad.<br>Las dos respuestas están bien.',
      botonSi: 'Sí, te perdono', botonNo: 'Todavía me duele'
    },
    finales: {
      perdon: { titulo: 'Gracias.', texto: 'No doy este momento por sentado.<br>Lo que pasó me enseñó; <b>lo que viene, lo pienso cuidar contigo.</b>' },
      duele: { titulo: 'Gracias por tu honestidad.', texto: 'Nadie puede exigirte sanar con prisa; yo, menos que nadie.<br><b>Tómate tu tiempo.</b> Esta carta seguirá guardada, y yo también aquí seguiré.' }
    }
  };

  /* ---------- Helpers ---------- */
  function html(id, v) { if (v != null) { var el = U.$(id); if (el) el.innerHTML = v; } }
  function text(id, v) { if (v != null) { var el = U.$(id); if (el) el.textContent = v; } }

  function aplicarTextos(c) {
    if (c.portada) { html('coverEyebrow', c.portada.eyebrow); html('coverTitle', c.portada.titulo); html('coverSub', c.portada.subtitulo); html('coverHint', c.portada.hint); }
    if (c.sobre) { html('envEyebrow', c.sobre.eyebrow); html('envHint', c.sobre.hint); }
    if (c.pregunta) { html('qTitle', c.pregunta.titulo); html('qSub', c.pregunta.subtitulo); text('forgiveBtn', c.pregunta.botonSi); text('notYetBtn', c.pregunta.botonNo); }
    if (c.finales) {
      if (c.finales.perdon) { html('forgivenTitle', c.finales.perdon.titulo); html('forgivenText', c.finales.perdon.texto); }
      if (c.finales.duele) { html('notyetTitle', c.finales.duele.titulo); html('notyetText', c.finales.duele.texto); }
    }
  }

  function tituloFinal() {
    var base = 'Gracias.';
    try { base = contenido.finales.perdon.titulo || base; } catch (e) {}
    var para = String(privado.para || '').trim();
    if (!para) return base;
    return base.replace(/\.$/, '') + ', ' + para + '.';
  }

  function duracionRafaga() {
    return (config && config.petalos && config.petalos.duracionRafaga) || 4.5;
  }

  /* ---------- Cerrojo (desbloqueo por carta) ---------- */
  function gateListo() {
    return !!(U.$('gateForm') && U.$('gateInput') && U.$('gateError') && U.$('gatePista'));
  }
  function claveSesion() { return 'disculpa-desbloqueada' + (ctx.id ? '-' + ctx.id : ''); }
  function cerrojoDesbloqueada() {
    try { return sessionStorage.getItem(claveSesion()) === 'si'; } catch (e) { return false; }
  }
  function desbloquear() {
    try { sessionStorage.setItem(claveSesion(), 'si'); } catch (e) {}
    try {
      history.replaceState(null, '', ctx.id ? ('?carta=' + encodeURIComponent(ctx.id)) : location.pathname);
    } catch (e) {}
    App.SceneManager.mostrar('cover');
  }

  function montarCerrojo() {
    if (cerrojoMontado) return;
    cerrojoMontado = true;
    if (privado.pista) U.$('gatePista').textContent = privado.pista;
    U.$('gateForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var hash = U.sha256Hex(U.normalizarClave(U.$('gateInput').value));
      if (hash === String(privado.clave || '').trim().toLowerCase()) {
        desbloquear();
      } else {
        this.classList.remove('erronea');
        void this.offsetWidth;
        this.classList.add('erronea');
        U.$('gateError').textContent = 'Esa no es la palabra… inténtalo de nuevo.';
        U.$('gateInput').value = '';
        U.$('gateInput').focus();
      }
    });
  }

  /* ---------- Eventos ---------- */
  function irAlSobre() {
    if (selloPuesto) return;
    selloPuesto = true;
    App.AudioFX.sello();
    App.SceneManager.mostrar('envelope');
  }

  function conectarEventos() {
    U.$('soundBtn').addEventListener('click', function () {
      App.AudioFX.alternar();
      this.classList.toggle('muted', !App.AudioFX.activado);
    });

    U.$('crearBtn').addEventListener('click', function () {
      if (App.Musica) App.Musica.arrancar();          /* melodía desde el editor */
      if (!App.Admin || !App.SceneManager) {
        console.error('[Disculpa] Falta js/features/admin.js o js/ui/scenes.js en el servidor.');
        var av = U.$('homeAviso');
        if (av) {
          av.textContent = 'No se pudo cargar el editor: falta un archivo en el servidor. Revisa js/features/admin.js.';
          av.classList.remove('hide');
        }
        return;
      }
      App.Admin.init({ php: ctx.phpOK, datos: null, id: null, edicion: false });
      App.SceneManager.mostrar('admin');
    });

    U.$('startBtn').addEventListener('click', irAlSobre);

    App.Envelope.alAbrir(function () {
      App.SceneManager.mostrar('letter');
      setTimeout(function () { App.Letter.reproducir(); }, 900);
    });

    U.$('forgiveBtn').addEventListener('click', function () {
      U.$('forgivenTitle').textContent = tituloFinal();
      App.SceneManager.mostrar('forgiven');
      App.AudioFX.latido();
      App.FX.rafaga(duracionRafaga());
    });
    U.$('reliveBtn').addEventListener('click', function () {
      App.AudioFX.latido();
      App.FX.rafaga(duracionRafaga() * .9);
    });
    U.$('notYetBtn').addEventListener('click', function () { App.SceneManager.mostrar('notyet'); });
    U.$('rereadBtn').addEventListener('click', function () {
      App.SceneManager.mostrar('letter');
      setTimeout(function () { App.Letter.reproducir(); }, 850);
    });
    U.$('restartBtn1').addEventListener('click', function () {
      selloPuesto = false;
      App.Envelope.reset();
      App.Letter.reiniciar();
      App.SceneManager.mostrar('cover');
    });
    U.$('restartBtn2').addEventListener('click', function () {
      selloPuesto = false;
      App.Envelope.reset();
      App.Letter.reiniciar();
      App.SceneManager.mostrar('cover');
    });
  }

  function iniciarBucle() {
    var prev = performance.now();
    (function frame(now) {
      var dt = Math.min((now - prev) / 1000, .06);
      prev = now;
      App.Dust.step(now, dt);
      App.FX.step(now);
      App.Parallax.step();
      requestAnimationFrame(frame);
    })(prev);
  }

  /* ---------- Arranque ---------- */
  function arrancar(cfg, cont, priv) {
    config = cfg;
    contenido = cont;
    privado = priv || {};

    aplicarTextos(cont);
    U.$('letterDate').textContent = U.fechaLarga();

    var para = String(privado.para || '').trim().slice(0, 24);
    U.$('envName').textContent = para ? 'Para ' + para : 'Para ti';
    U.$('letterTo').textContent = para ? 'Para ' + para : 'Para ti';
    App.Letter.establecerNombres({ to: para, from: String(privado.de || '').trim().slice(0, 24) });
    U.$('coverForm').classList.add('hide');
    U.$('startBtn').textContent = 'Abrir la carta';

    var contenidoCarta = (privado.bloques && privado.bloques.length)
      ? { despedida: privado.despedida || 'Con todo mi corazón,', bloques: privado.bloques }
      : cont.carta;

    App.Dust.init(cfg.polvo);
    App.FX.init(cfg.petalos);
    App.Parallax.init();
    App.SceneManager.init(ESCENAS);
    App.SceneManager.alCambiar(function (n) {
    App.Parallax.setActivo(n === 'envelope');
      if (App.Musica) App.Musica.arrancar();   /* la melodía entra con cada escena */
    });
    App.Envelope.init();
    App.Letter.init();
    App.Letter.cargarContenido(contenidoCarta);
    App.Typewriter.configurar(cfg.maquina);
    conectarEventos();

    if (ctx.modo === 'admin') {
      App.Admin.init({
        php: ctx.phpOK,
        datos: privado && privado.clave ? privado : null,
        id: ctx.id,
        edicion: !!(ctx.id && privado && privado.clave)
      });
      App.SceneManager.mostrar('admin');

    } else if (ctx.modo === 'lectura') {
      var k = String(ctx.k || '').trim().toLowerCase();
      if (k && k === String(privado.clave || '').trim().toLowerCase()) {
        desbloquear();
      } else if (gateListo() && !cerrojoDesbloqueada()) {
        montarCerrojo();
        if (k) U.$('gateError').textContent = 'El enlace que abriste ya no coincide con esta carta. Escribe la palabra a mano.';
        App.SceneManager.mostrar('gate');
        setTimeout(function () { try { U.$('gateInput').focus(); } catch (e) {} }, 700);
      } else {
        App.SceneManager.mostrar('cover');
      }

    } else {
      var aviso = U.$('homeAviso');
      if (aviso) {
        if (ctx.error) {
          aviso.textContent = ctx.error;
          aviso.classList.remove('hide');
        } else if (!ctx.phpOK) {
          aviso.textContent = 'Este servidor aún no puede crear cartas: necesita un hosting con PHP (por ejemplo, InfinityFree).';
          aviso.classList.remove('hide');
        }
      }
      App.SceneManager.mostrar('home');
    }

    iniciarBucle();
    quitarBoot();
  }

  function quitarBoot() {
    var b = U.$('boot');
    if (!b) return;
    b.classList.add('oculto');
    setTimeout(function () { if (b.parentNode) b.remove(); }, 700);
  }

  function avisoFallback(archivo, err) {
    console.warn('[Disculpa] AJAX falló para ' + archivo + ' → ' + err.message + '. Usando respaldo local.');
  }

  /* ---------- Red de seguridad ---------- */
  function salvavidas(detalle) {
    if (!document.getElementById('boot')) return;
    try { console.error('[Disculpa] El arranque falló' + (detalle ? ' — ' + detalle : '') + '.'); } catch (e) {}
    try {
      App.SceneManager.init(ESCENAS);
      App.SceneManager.mostrar('home');
    } catch (e) {
      var h = document.getElementById('scene-home');
      if (h) h.classList.add('active');
    }
    var b = document.getElementById('boot');
    if (b) { b.style.transition = 'opacity .4s ease'; b.style.opacity = '0'; setTimeout(function () { b.remove(); }, 450); }
  }
  window.addEventListener('error', function () { if (document.getElementById('boot')) salvavidas('error de script'); });
  window.addEventListener('unhandledrejection', function () { if (document.getElementById('boot')) salvavidas('promesa sin manejar'); });
  setTimeout(function () { if (document.getElementById('boot')) salvavidas('tiempo de carga agotado'); }, 12000);

  /* ---------- Carga inicial ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    console.info('[Disculpa] Ejecutando: ' + VERSION);   /* firma de versión */
    var NO_CACHE = '?t=' + Date.now();

    var qs; try { qs = new URLSearchParams(location.search); } catch (e) { qs = null; }
    var id = qs ? (qs.get('carta') || '').trim() : '';
    var k = qs ? (qs.get('k') || '').trim() : '';

    /* #admin SOLO vale junto a ?carta=ID (edición de esa carta).
       Si llega solo (autocompletado, historial), se limpia la barra
       y se muestra la landing: nadie cae al editor por accidente. */
    var esAdmin = !!(id && /#admin/i.test(location.hash));
    if (!id && /#admin/i.test(location.hash)) {
      try { history.replaceState(null, '', location.pathname); } catch (e) {}
    }
    ctx.id = id || null;
    ctx.k = k || null;

    /* sonda: ¿hay PHP? (carta.php sin id responde 200 con ok:false) */
    var sonda = App.Ajax.json('api/carta.php' + NO_CACHE)
      .then(function () { ctx.phpOK = true; })
      .catch(function () { ctx.phpOK = false; });

    var cfgP = App.Ajax.json('data/config.json' + NO_CACHE)
      .catch(function (e) { avisoFallback('config.json', e); return CONFIG_FALLBACK; });
    var cartaP = App.Ajax.json('data/carta.json' + NO_CACHE)
      .catch(function (e) { avisoFallback('carta.json', e); return CONTENIDO_FALLBACK; });

    var cartaDatos = id
      ? App.Ajax.json('api/carta.php?id=' + encodeURIComponent(id) + '&t=' + Date.now())
          .catch(function () { ctx.error = 'No se pudo cargar esa carta (quizá no exista).'; return null; })
      : Promise.resolve(null);

    Promise.all([sonda, cfgP, cartaP, cartaDatos]).then(function (res) {
      var api = res[3];
      if (api && api.ok && api.datos) {
        privado = api.datos;
        ctx.modo = esAdmin ? 'admin' : 'lectura';
      } else if (id) {
        if (!ctx.error) ctx.error = 'Esa carta no existe (o fue retirada).';
        ctx.modo = 'inicio';
      } else {
        ctx.modo = esAdmin ? 'admin' : 'inicio';
      }
      try { arrancar(res[1], res[2], privado); }
      catch (e) { salvavidas(e && e.message); }
    }).catch(function (err) { salvavidas(err && err.message); });
  });
})(window.App = window.App || {});