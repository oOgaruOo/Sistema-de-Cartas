<?php
/* carta.php · GET ?id=codigo
   - Sin id: sonda (el frontend detecta así si el hosting tiene PHP).
   - Con id: devuelve los datos PÚBLICOS de la carta (nunca el hash del editor). */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (!isset($_GET['id'])) { echo json_encode(['ok' => false, 'error' => 'falta id']); exit; }

 $id = preg_replace('/[^a-zA-Z0-9]/', '', (string)$_GET['id']);
if (strlen($id) < 6 || strlen($id) > 20) { echo json_encode(['ok' => false, 'error' => 'id inválido']); exit; }

 $archivo = __DIR__ . '/../data/cartas/' . $id . '.json';
if (!is_file($archivo)) { echo json_encode(['ok' => false, 'error' => 'carta no encontrada']); exit; }

 $datos = json_decode(file_get_contents($archivo), true);
if (!is_array($datos) || empty($datos['clave']) || empty($datos['bloques'])) {
  echo json_encode(['ok' => false, 'error' => 'carta corrupta']);
  exit;
}

unset($datos['admin']);   /* el hash del editor jamás viaja al navegador */
echo json_encode(['ok' => true, 'datos' => $datos]);